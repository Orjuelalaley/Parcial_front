export interface Libro {
    titulo: String;
    referencia: String;
    autor: String;
    precio: number;
    ubicacion: String;
  }